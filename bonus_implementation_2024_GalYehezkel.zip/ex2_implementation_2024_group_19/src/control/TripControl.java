package control;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entity.Consts;
import entity.Place;
import entity.Trip;

public class TripControl implements Serializable {
	

		private static final long serialVersionUID = 1L;
		
	    private static TripControl instance = null;

	    public static TripControl getInstance() {
        if (instance == null) {
            instance = new TripControl();
        }
        return instance;
	    }
	   
	    
	    
	    public ArrayList<Trip> getTrips() {
			ArrayList<Trip> results = new ArrayList<Trip>();
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_TRIP);
						ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						int i = 1;
						results.add(new Trip(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getDate(i++), rs.getDate(i++), rs.getInt(i++)));
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
	    
	    public ArrayList<Place> getPlaces() {
			ArrayList<Place> results = new ArrayList<Place>();
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACE);
						ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						int i = 1;
						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
	    
	    public boolean removePlace(long placeID, long tripnum) {
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						CallableStatement stmt = conn.prepareCall(Consts.SQL_DEL_PLACE)) {
					
					stmt.setLong(1, placeID);
					stmt.setLong(2, tripnum);
					stmt.executeUpdate();
					return true;
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return false;
		}
	    
	    public boolean addPlace(long placenum, long tripnum) {
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_PLACE)) {
					
					stmt.setLong(1, placenum); // can't be null
					stmt.setLong(2, tripnum); // can't be null
				
					stmt.executeUpdate();
					return true;
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return false;
		}
	    
	    public ArrayList<Place> getOKPlace(int tripnum) {
	 			ArrayList<Place> results = new ArrayList<Place>();
	 			try {
	 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
	 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_TRIP_OK_PLACE);) {
	 					
						stmt.setInt(1, tripnum);
	
	 					ResultSet rs = stmt.executeQuery(); 
	 					while (rs.next()) {
	 						int i = 1;
	 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
									rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
	 					}
	 					
	 				} catch (SQLException e) {
	 					e.printStackTrace();
	 				}
	 			} catch (ClassNotFoundException e) {
	 				e.printStackTrace();
	 			}
	 			return results;
	 		}
	    
	    public ArrayList<Place> getOKPlaceByPrice(int tripnum, String price) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACES_NOT_IN_TRIP_BY_PRICE);) {
 					
					stmt.setInt(1, tripnum);
					stmt.setString(2, price);

 					ResultSet rs = stmt.executeQuery(); 
 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    public ArrayList<Place> getOKPlaceByKitchen(int tripnum, String kitchen) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACES_NOT_IN_TRIP_BY_KITCHEN);) {
 					
					stmt.setString(1, kitchen);
					stmt.setInt(2, tripnum);

 					ResultSet rs = stmt.executeQuery(); 
 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    public ArrayList<Place> getOKPlaceByAccommandationStyle(int tripnum, int acoStyle) {
	 			ArrayList<Place> results = new ArrayList<Place>();
	 			try {
	 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
	 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACES_NOT_IN_TRIP_BY_ACCOMMANDATIONSTYLE);) {
	 					
						stmt.setInt(1, tripnum);
						stmt.setInt(2, acoStyle);

	 					ResultSet rs = stmt.executeQuery(); 
	 					while (rs.next()) {
	 						int i = 1;
	 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
									rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
	 					}
	 					
	 				} catch (SQLException e) {
	 					e.printStackTrace();
	 				}
	 			} catch (ClassNotFoundException e) {
	 				e.printStackTrace();
	 			}
	 			return results;
	 		}
	    
	    public ArrayList<Place> getOKPlaceByReccommandation(int tripnum1, int tripnum2, int dis) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACES_BY_DISTANCE);) {
 					
					stmt.setInt(1, dis);
					stmt.setInt(2, tripnum1);
					stmt.setInt(3, tripnum2);
 					System.out.println("dis");

 					ResultSet rs = stmt.executeQuery(); 

 					while (rs.next()) {
 						int i = 1;
 						results.addAll(getPlacebyNum(rs.getInt(i++)));
 					}
 					
 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	

	    
	    public ArrayList<Place> getOKPlaceByAVGReviews(int tripnum1) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACES_BY_PLACE_OK_AND_REVIEWS1);) {
 					
					stmt.setInt(1, tripnum1);

 					ResultSet rs = stmt.executeQuery();

 					while (rs.next()) {
 						int i = 1;
 						results.addAll(getPlacebyNum(rs.getInt(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	     
	    
	    public ArrayList<Place> getPlacebyNum(int placenum) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACE_BY_PLACE_NUM);) {
 					
					stmt.setInt(1, placenum);

 					ResultSet rs = stmt.executeQuery();

 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    public ArrayList<Place> getPlaceintrip(int tripnum) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACE_IN_TRIP);) {
 					
					stmt.setInt(1, tripnum);

 					ResultSet rs = stmt.executeQuery();

 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    
	    public boolean addTrip(String name, String desc, String start, String end, Long uNIQMEMBER) {
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_TRIP)) {
					
					stmt.setString(1, name);
					stmt.setString(2, desc);
					stmt.setDate(3, Date.valueOf(start));
					stmt.setDate(4, Date.valueOf(end));
					stmt.setLong(5, uNIQMEMBER);
					
					stmt.executeUpdate();
					return true;
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return false;
		}
	    
}

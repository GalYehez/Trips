package control;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import entity.Consts;
import entity.Place;
import entity.Restaurant;

public class PlacesControl implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static PlacesControl instance = null;

    public static PlacesControl getInstance() {
    if (instance == null) {
        instance = new PlacesControl();
    }
    return instance;
    }

	public static boolean addPlace(Place c) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_NEWPLACE)) {
								
				stmt.setString(1, c.getName()); // can't be null
				stmt.setString(2, c.getDescription()); // can't be null
				stmt.setLong(3, c.getCoordinates()); // can't be null
				stmt.setString(4, c.getPricelevel()); // can't be null
				stmt.setLong(5, c.getCity()); // can't be null
				stmt.setString(6, c.getCountry()); // can't be null

				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	 public static void exportPlacesToXML() {
	        try {
	            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	            try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
	                    PreparedStatement stmt = conn.prepareStatement(
	                            Consts.SQL_SEL_PLACE);
	                    ResultSet rs = stmt.executeQuery()) {
	                
	                // create document object.
	                Document doc = DocumentBuilderFactory.newInstance()
	                        .newDocumentBuilder().newDocument();
	                
	                // push root element into document object.
	                Element rootElement = doc.createElement("Places_info");
	                rootElement.setAttribute("exportDate", LocalDateTime.now().toString());
	                doc.appendChild(rootElement);
	                
	                while (rs.next()) {     // run on all customer records..
	                    // create customer element.
	                    Element customer = doc.createElement("Place");
	                    
	                    // assign key to customer.
	                    Attr attr = doc.createAttribute("ID");
	                    attr.setValue(rs.getString(1));
	                    customer.setAttributeNode(attr);
	                    
	                    // push elements to customer.
	                    for (int i = 2; i <= rs.getMetaData().getColumnCount(); i++) {
	                        Element element = doc.createElement(
	                                rs.getMetaData().getColumnName(i)); // push element to doc.
	                        rs.getObject(i); // for wasNull() check..
	                        element.appendChild(doc.createTextNode(
	                                rs.wasNull() ? "" : rs.getString(i)));  // set element value.
	                        customer.appendChild(element);  // push element to customer.
	                    }
	                    
	                    // push customer to document's root element.
	                    rootElement.appendChild(customer);
	                }
	                
	                // write the content into xml file
	                
	                DOMSource source = new DOMSource(doc);
	                File file = new File("xml/places.xml");
	                file.getParentFile().mkdir(); // create xml folder if doesn't exist.
	                StreamResult result = new StreamResult(file);
	                TransformerFactory factory = TransformerFactory.newInstance();
	                
	                // IF CAUSES ISSUES, COMMENT THIS LINE.
	                factory.setAttribute("indent-number", 2);
	                //
	                
	                Transformer transformer = factory.newTransformer();
	                
	                // IF CAUSES ISSUES, COMMENT THESE 2 LINES.
	                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	                transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
	                //
	                
	                transformer.transform(source, result);
	                
	                System.out.println("Places data exported successfully!");
	            } catch (SQLException | NullPointerException | ParserConfigurationException
	                    | TransformerException e) {
	                e.printStackTrace();
	            }
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }

	    /**
	     * imports customers from xml to db.
	     * @param path xml filepath.
	     */
	    public static void importPlacesFromXML(String path) {
	    	try {
				Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(path));
				doc.getDocumentElement().normalize();
				NodeList nl = doc.getElementsByTagName("place");
				
				int errors = 0;
				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i).getNodeType() == Node.ELEMENT_NODE) {
						Element el = (Element) nl.item(i);
						Place c = new Place(el.getElementsByTagName("name").item(0).getTextContent(),
								el.getElementsByTagName("description").item(0).getTextContent(),
								Integer.valueOf(el.getElementsByTagName("landmark_number").item(0).getTextContent().toString()),
								el.getElementsByTagName("price_level").item(0).getTextContent(),
								Integer.valueOf(el.getElementsByTagName("city").item(0).getTextContent().toString()),
								el.getElementsByTagName("country").item(0).getTextContent());
					
						if(!addPlace(c))
							errors++;	
					}
				}
				
				System.out.println((errors == 0) ? "Places data imported successfully!" : 
					String.format("Places data imported with %d errors!", errors));
				
			} catch (SAXException | IOException | ParserConfigurationException e) {
				e.printStackTrace();
			}
	    }
	    
	    public ArrayList<Place> getOKPlaceByCity(int city) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACE_BY_CITY);) {
 					
					stmt.setLong(1, city);

 					ResultSet rs = stmt.executeQuery(); 
 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    public ArrayList<Place> getOKPlaceByCountry(String country) {
 			ArrayList<Place> results = new ArrayList<Place>();
 			try {
 				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
 				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
 						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_PLACE_BY_COUNTRY);) {
 					
					stmt.setString(1, country);

 					ResultSet rs = stmt.executeQuery(); 
 					while (rs.next()) {
 						int i = 1;
 						results.add(new Place(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getInt(i++), rs.getString(i++),rs.getInt(i++), rs.getString(i++)));
 					}
 					
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			} catch (ClassNotFoundException e) {
 				e.printStackTrace();
 			}
 			return results;
 		}
	    
	    public boolean updateKitchenStyle(String kitchen, long numplace) {
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						CallableStatement stmt = conn.prepareCall(Consts.SQL_UP_KITCHENSTYLE)) {
			
					stmt.setString(1, kitchen);				
					stmt.setLong(2, numplace);
						
					stmt.executeUpdate();
					return true;
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return false;
		}
	    
	    public ArrayList<Restaurant> getRestaurant() {
			ArrayList<Restaurant> results = new ArrayList<Restaurant>();
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_REST);
						ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						int i = 1;
						results.add(new Restaurant(rs.getInt(i++), rs.getString(i++)));
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
	    
	    
	    

}

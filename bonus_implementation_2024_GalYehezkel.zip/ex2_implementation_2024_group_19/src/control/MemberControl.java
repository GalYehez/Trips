package control;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Consts;
import entity.Member;
import entity.Trip;

public class MemberControl implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
    private static MemberControl instance = null;

    public static MemberControl getInstance() {
    if (instance == null) {
        instance = new MemberControl();
    }
    return instance;
    }
    
    public ArrayList<Trip> getTrips() {
		ArrayList<Trip> results = new ArrayList<Trip>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_TRIP);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Trip(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
							rs.getDate(i++), rs.getDate(i++), rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
    
    //get all the members
    public ArrayList<Member> getMembers() {
		ArrayList<Member> results = new ArrayList<Member>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_MEMBER);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Member(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
							rs.getString(i++), rs.getString(i++)));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
    
    public boolean removeMember(long memberID, long tripnum) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_DEL_MEMBER)) {
				
				stmt.setLong(1, memberID);
				stmt.setLong(2, tripnum);
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
    
    public boolean addMember(long membernum, long tripnum) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_MEMBER)) {
				
				stmt.setLong(1, membernum); // can't be null
				stmt.setLong(2, tripnum); // can't be null
			
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
    
    public ArrayList<Member> getOKmember(int tripnum) {
			ArrayList<Member> results = new ArrayList<Member>();
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_TRIP_OK_MEMBER);) {
					
				stmt.setInt(1, tripnum);

					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) {
						int i = 1;
						results.add(new Member(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getString(i++), rs.getString(i++)));
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
    
    public ArrayList<Member> getMemberintrip(int tripnum) {
			ArrayList<Member> results = new ArrayList<Member>();
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_MEMBER_IN_TRIP);) {
					
				stmt.setInt(1, tripnum);

					ResultSet rs = stmt.executeQuery();

					while (rs.next()) {
						int i = 1;
						results.add(new Member(rs.getInt(i++), rs.getString(i++), rs.getString(i++),
								rs.getString(i++), rs.getString(i++)));
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return results;
		}
    
    
    public static boolean addNewMember(long ID, String FirstName, String LastName, String Email) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_MEMBER_NEW)) {
				
				stmt.setLong(1, ID); 
				stmt.setString(2, FirstName);
				stmt.setString(3, LastName);
				stmt.setString(4, Email);
	
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

    public static String getPassmember(long id) {
		ArrayList<String> results = new ArrayList<String>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_MEMBER_PASS);) {
				
			stmt.setLong(1, id);

			 
				ResultSet rs = stmt.executeQuery(); 
				
				
				while (rs.next()) {
					int i = 1;
					results.add(rs.getString(i++));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results.get(0);
	}
    
    public static String getUniqueNumMember(String pass) {
		ArrayList<String> results = new ArrayList<String>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_UNIQUENUM);) {
				
				stmt.setString(1, pass);

				ResultSet rs = stmt.executeQuery(); 
				
				while (rs.next()) {
					int i = 1;
					results.add(rs.getString(i++));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results.get(0);
	}
  
    
    public static ArrayList<Integer> getTripsOfMember(Long numMember) {
		ArrayList<Integer> results = new ArrayList<Integer>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_TRIPS_OF_MEMBER);) {
				
				stmt.setLong(1, numMember);

				ResultSet rs = stmt.executeQuery(); 
				
				while (rs.next()) {
					int i = 1;
					results.add(rs.getInt(i++));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
}

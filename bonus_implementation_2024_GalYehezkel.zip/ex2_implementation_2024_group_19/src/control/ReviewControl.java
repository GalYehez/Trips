package control;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import org.json.simple.JsonArray;
import org.json.simple.JsonObject;
import org.json.simple.Jsoner;

import entity.Consts;
import entity.Review;

public class ReviewControl implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
    private static ReviewControl instance = null;

    public static ReviewControl getInstance() {
    if (instance == null) {
        instance = new ReviewControl();
    }
    return instance;
    }
    
    public ArrayList<Review> getReviews() {
		ArrayList<Review> results = new ArrayList<Review>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_REV);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					LocalDateTime loc = rs.getTimestamp("time").toLocalDateTime();
					results.add(new Review(rs.getInt(i++), rs.getInt(i++), loc, rs.getInt(i=i+1), rs.getInt(i=i+1), rs.getString(i=i+1)));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
    
    public boolean addReview(long score, long nummember, long PlaceNumber, String txt) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_REV)) {
				
				stmt.setLong(1, score); // can't be null
				stmt.setLong(2, nummember); // can't be null
				stmt.setLong(3, PlaceNumber);
				stmt.setString(4, txt);
			
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
    
    public boolean updateReview(long score, long numrevtoup, String txt) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_UP_REV)) {
		
				stmt.setLong(1, score); // can't be null
				stmt.setString(2, txt);				
				stmt.setLong(3, numrevtoup); // can't be null
					
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
    
    /**
     * exports reviews from db to json.
     */
	public void exportReviewsToJSON() {
    	   try {
               Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
               try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
                       PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_REV);
                       ResultSet rs = stmt.executeQuery()) {
            	   JsonArray reviews = new JsonArray();
                   while (rs.next()) {
                	   JsonObject review = new JsonObject();
                	   
                	   for (int i = 1; i < rs.getMetaData().getColumnCount(); i++)
                		   review.put(rs.getMetaData().getColumnName(i), rs.getString(i));
                	   
                	   reviews.add(review);
                   }
                   
            	   JsonObject doc = new JsonObject();
            	   doc.put("Reviews_info", reviews);
                   
                   File file = new File("json/reviews.json");
                   file.getParentFile().mkdir();
                   
                   try (FileWriter writer = new FileWriter(file)) {
                	   writer.write(Jsoner.prettyPrint(doc.toJson()));
                	   writer.flush();
                       System.out.println("reviews data exported successfully!");
                   } catch (IOException e) {
                	   e.printStackTrace();
                   }
               } catch (SQLException | NullPointerException e) {
                   e.printStackTrace();
               }
           } catch (ClassNotFoundException e) {
               e.printStackTrace();
           }	
    }
	
	

}

package boundary;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.PlacesControl;
import control.ReviewControl;
import control.TripControl;
import entity.Place;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class PlacesNew extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel tableModel;


	public PlacesNew() {
		setBounds(100, 100, 450, 300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setToolTipText("");
		table.setForeground(Color.BLACK);
		table.setEnabled(false);
		table.setCellSelectionEnabled(true);
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(30, 146, 434, 326);
		contentPane.add(table);
		
		String[] columnNames = {"uniqueSerielNumber", "name", "p.level", "cityCode","Country"};
	     tableModel = new DefaultTableModel(columnNames,0);
	     
		table.setModel(tableModel);
		
		
		JButton btnNewButton = new JButton("Import places from XML");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlacesControl.importPlacesFromXML("xml/file (2).xml");
			}
		});
		btnNewButton.setBounds(141, 44, 207, 23);
		contentPane.add(btnNewButton);
		
		JButton btnExportAllPlaces = new JButton("Export all places to XML");
		btnExportAllPlaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlacesControl.exportPlacesToXML();
			}
		});
		btnExportAllPlaces.setBounds(141, 483, 207, 23);
		contentPane.add(btnExportAllPlaces);
		
		JButton btnSeeAllPlaces = new JButton("See All Places");
		btnSeeAllPlaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);

					ArrayList<Place> al = TripControl.getInstance().getPlaces();

					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
			}
		});
		btnSeeAllPlaces.setBounds(30, 112, 139, 23);
		contentPane.add(btnSeeAllPlaces);
		
		JButton btnExportAllReviews = new JButton("Export all reviews to JSON");
		btnExportAllReviews.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReviewControl.getInstance().exportReviewsToJSON();
			}
		});
		btnExportAllReviews.setBounds(141, 517, 207, 23);
		contentPane.add(btnExportAllReviews);
		
		JLabel lblNewLabel = new JLabel("Hello Vice President!");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(30, 11, 243, 22);
		contentPane.add(lblNewLabel);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(306, 553, 170, 23);
		contentPane.add(btnToTheLogin);
		
	

	}
}

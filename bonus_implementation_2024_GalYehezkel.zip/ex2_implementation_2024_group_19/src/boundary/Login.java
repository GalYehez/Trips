package boundary;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.MemberControl;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public static Long UNIQMEMBER = null;
	private JTextField textField;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		

		textField = new JTextField();
		textField.setBounds(200, 58, 114, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Member");
		btnNewButton.setBounds(108, 151, 206, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				MemberControl.getInstance();
				UNIQMEMBER = Long.valueOf(MemberControl.getUniqueNumMember(textField.getText()));
				}
				catch (Exception e1) {
					JOptionPane.showMessageDialog(null,"error passward", "alert msg", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
				
				if(UNIQMEMBER != null)
				{
				Menu menu = new Menu();
				menu.setVisible(true);
				dispose();
				}
				else
					JOptionPane.showMessageDialog(null,"error passward", "alert msg", JOptionPane.ERROR_MESSAGE);
				
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		
		JButton btnUser = new JButton("User - New member");
		btnUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				UserScreen p = new UserScreen();
				p.setVisible(true);
				dispose();
				
			}
		});
		btnUser.setBounds(108, 117, 206, 23);
		contentPane.add(btnUser);
		
		JButton btnVicePresident = new JButton("Vice President");
		btnVicePresident.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(textField.getText().equals("admin"))
				{
				PlacesNew p = new PlacesNew();
				p.setVisible(true);
				dispose();
				}
				else
					JOptionPane.showMessageDialog(null,"error passward", "alert msg", JOptionPane.ERROR_MESSAGE);
				
			}
		});
		btnVicePresident.setBounds(108, 185, 206, 23);
		contentPane.add(btnVicePresident);
		
		
		JLabel lblNewLabel = new JLabel("passward:");
		lblNewLabel.setBounds(108, 61, 93, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblSignInAs = new JLabel("Sign in as:");
		lblSignInAs.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSignInAs.setBounds(163, 86, 93, 28);
		contentPane.add(lblSignInAs);
		
		JButton btnVpOfCulture = new JButton("VP of Culture");
		btnVpOfCulture.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().equals("Cadmin"))
				{
					VPCultureKitchenStyle p = new VPCultureKitchenStyle();
				p.setVisible(true);
				dispose();
				}
				else
					JOptionPane.showMessageDialog(null,"error passward", "alert msg", JOptionPane.ERROR_MESSAGE);
				
				
			}
		});
		btnVpOfCulture.setBounds(108, 219, 206, 23);
		contentPane.add(btnVpOfCulture);
		
		JLabel lblNewLabel_1 = new JLabel("Hello, please choose:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 14, 206, 20);
		contentPane.add(lblNewLabel_1);
	}
}

package boundary;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.MemberControl;
import control.TripControl;
import entity.Member;
import entity.Trip;
import java.awt.Font;

public class TripMemberscreen extends JInternalFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableplaces;
	private DefaultTableModel tableModel;
	private DefaultTableModel tableModel1;
	private DefaultTableModel tableModel2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable tabletrips;
	private JTable tableplacetrip;
	private JTextField oktrips;

	/**
	 * Create the frame.
	 */
	public TripMemberscreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		tabletrips = new JTable();
		tabletrips.setCellSelectionEnabled(true);
		tabletrips.setEnabled(false);
		tabletrips.setToolTipText("");
		tabletrips.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"uniqueTripNumber", "start", "end", "createorNum", "description", "name"
			}
		));
		
		
		String[] columnNamesTrip = {"uniqueTripNumber", "start", "end", "createorNum", "description", "name"};
	    tableModel1 = new DefaultTableModel(columnNamesTrip,0);
		
		tabletrips.setBounds(20, 56, 431, 70);
		contentPane.add(tabletrips);
		
        Object[] rowData = {"uniqueNum", "start", "end", "createor", "description", "name"};
        tableModel1.addRow(rowData);


		
		tabletrips.setModel(tableModel1);
		
		JButton getTrips = new JButton("Get All Trips");
		getTrips.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<Trip> arrayList =TripControl.getInstance().getTrips();

				 for (Trip element : arrayList) {
			            Object[] rowData = {element.getUniqueTripNumber(), element.getStart(), element.getEnd(), element.getCreateorNum(), element.getDescription(), element.getName()};
			            tableModel1.addRow(rowData);
			        }
				
				
			}
		});
		getTrips.setBounds(15, 28, 116, 23);
		contentPane.add(getTrips);
		
		
		
		tableplaces = new JTable();
		tableplaces.setToolTipText("");
		tableplaces.setForeground(Color.BLACK);
		tableplaces.setEnabled(false);
		tableplaces.setCellSelectionEnabled(true);
		tableplaces.setBackground(Color.LIGHT_GRAY);
		tableplaces.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null},
				},
				new String[] {
					"UniqueNumber", "ID", "Fname", "Lname","email"
				}
			));
		tableplaces.setBounds(20, 177, 434, 100);
		
		String[] columnNames = {"UniqueNumber", "ID", "Fname", "Lname","email"};
	     tableModel = new DefaultTableModel(columnNames,0);

	     Object[] rowData1 = {"UniqueNumber", "ID", "Fname", "Lname","email"};
	     tableModel.addRow(rowData1);
	     
		 tableplaces.setModel(tableModel);
		
		getContentPane().add(tableplaces);
		
		JButton gatplaces = new JButton("See All Members");
		gatplaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            tableModel.setRowCount(0);
	            Object[] rowData1 = {"UniqueNumber", "ID", "Fname", "Lname","email"};

	   	     	tableModel.addRow(rowData1);

				ArrayList<Member> al = MemberControl.getInstance().getMembers();

				 for (Member element : al) {
			            Object[] rowData = {element.getUniqueNumber(), element.getID(), element.getFname(), element.getLname(), element.getEmail()};
			            tableModel.addRow(rowData);
			        }
				
				
			}
		});
		gatplaces.setBounds(10, 137, 130, 23);
		contentPane.add(gatplaces);
		
		JLabel lblNewLabel = new JLabel("Add member to trip:");
		lblNewLabel.setBounds(20, 458, 116, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(125, 480, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(125, 511, 86, 20);
		contentPane.add(textField_1);
		
		JLabel lblNumberPlace = new JLabel("Number member:");
		lblNumberPlace.setBounds(20, 483, 143, 14);
		contentPane.add(lblNumberPlace);
		
		JLabel lblNumberTrip = new JLabel("Number Trip:");
		lblNumberTrip.setBounds(20, 514, 95, 14);
		contentPane.add(lblNumberTrip);
		
		JLabel lblAutomaticState = new JLabel("Choose trip:");
		lblAutomaticState.setBounds(22, 306, 109, 14);
		contentPane.add(lblAutomaticState);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(116, 303, 69, 20);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("Add member");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
			if(MemberControl.getInstance().addMember( Integer.valueOf(textField.getText()),  Integer.valueOf(textField_1.getText()) ))
				JOptionPane.showMessageDialog(null, "member added", "plain msg", JOptionPane.PLAIN_MESSAGE);
			else
				JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnNewButton.setBounds(68, 550, 95, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblRemovePlaceFrom = new JLabel("Remove member from trip:");
		lblRemovePlaceFrom.setBounds(246, 455, 177, 14);
		contentPane.add(lblRemovePlaceFrom);
		
		JLabel lblNumberPlace_1 = new JLabel("Number member:");
		lblNumberPlace_1.setBounds(246, 483, 121, 14);
		contentPane.add(lblNumberPlace_1);
		
		JLabel lblNumberTrip_1 = new JLabel("Number Trip:");
		lblNumberTrip_1.setBounds(246, 514, 95, 14);
		contentPane.add(lblNumberTrip_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(351, 511, 86, 20);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(351, 480, 86, 20);
		contentPane.add(textField_4);
		
		JButton btnRemovePlace = new JButton("Remove member");
		btnRemovePlace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(MemberControl.getInstance().removeMember( Integer.valueOf(textField_4.getText())  ,  Integer.valueOf(textField_3.getText())))
				JOptionPane.showMessageDialog(null, "place removed", "plain msg", JOptionPane.PLAIN_MESSAGE);
			else
				JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnRemovePlace.setBounds(279, 550, 130, 23);
		contentPane.add(btnRemovePlace);
		
		tableplacetrip = new JTable();
		tableplacetrip.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		tableplacetrip.setToolTipText("");
		tableplacetrip.setForeground(Color.BLACK);
		tableplacetrip.setEnabled(false);
		tableplacetrip.setCellSelectionEnabled(true);
		tableplacetrip.setBackground(Color.LIGHT_GRAY);
		tableplacetrip.setBounds(20, 356, 431, 61);
		contentPane.add(tableplacetrip);
		
		String[] columnPlaceInTrip = {"UniqueNumber", "ID", "Fname", "Lname","email"};
	    tableModel2 = new DefaultTableModel(columnPlaceInTrip,0);
		
		tableplacetrip.setModel(tableModel2);
		 Object[] rowDataa = {"UniqueNumber", "ID", "Fname", "Lname","email"};
	     tableModel2.addRow(rowDataa);
	     	
		JLabel lblNewLabel_3 = new JLabel("Members in the trip you chose:");
		lblNewLabel_3.setBounds(20, 331, 321, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("PERFECT TRIP - Manage trip's members");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(119, 0, 385, 29);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<Member> al5 = MemberControl.getInstance().getMemberintrip(Integer.valueOf(textField_2.getText()));
	            tableModel2.setRowCount(0);
	   	     tableModel2.addRow(rowDataa);
	   	     
	   	  for (Member element : al5) {
	            Object[] rowData = {element.getUniqueNumber(), element.getID(), element.getFname(), element.getLname(), element.getEmail()};
	            tableModel2.addRow(rowData);
	        }
	   	  
			}
		});
		btnNewButton_1.setBounds(239, 327, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblYouCanEdit = new JLabel("You can edit these trips:");
		lblYouCanEdit.setBounds(20, 417, 217, 14);
		contentPane.add(lblYouCanEdit);
		
		oktrips = new JTextField();
		oktrips.setColumns(10);
		oktrips.setBounds(20, 437, 149, 20);
		contentPane.add(oktrips);
		
		ArrayList<String> stringList = new ArrayList<>();
        MemberControl.getInstance();
		for (Integer intValue : MemberControl.getTripsOfMember(Login.UNIQMEMBER) ) {
            String strValue = Integer.toString(intValue);
            stringList.add(strValue);
        }
        
        StringBuilder stringBuilder = new StringBuilder();
        for (String str : stringList) {
            stringBuilder.append(str).append("\n"); // Add each string followed by a newline character
        }
        String concatenatedText = stringBuilder.toString();
		
		oktrips.setText(concatenatedText);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(310, 137, 170, 23);
		contentPane.add(btnToTheLogin);
	}
}

package boundary;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.TripControl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewTrip extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField start;
	private JTextField desc;
	private JTextField name;
	private JTextField end;

	public NewTrip() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);	
		
		JLabel lblAddTrip = new JLabel("Add trip:");
		lblAddTrip.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAddTrip.setBounds(10, 23, 133, 14);
		contentPane.add(lblAddTrip);
		
		JLabel lblTripName = new JLabel("Trip name:");
		lblTripName.setBounds(10, 48, 102, 14);
		contentPane.add(lblTripName);
		
		JLabel lblDescription = new JLabel("Description:");
		lblDescription.setBounds(10, 82, 102, 14);
		contentPane.add(lblDescription);
		
		JLabel lblStartdate = new JLabel("StartDate:");
		lblStartdate.setBounds(10, 123, 133, 14);
		contentPane.add(lblStartdate);
		
		start = new JTextField();
		start.setColumns(10);
		start.setBounds(133, 120, 96, 20);
		contentPane.add(start);
		
		desc = new JTextField();
		desc.setColumns(10);
		desc.setBounds(133, 79, 96, 20);
		contentPane.add(desc);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(133, 48, 96, 20);
		contentPane.add(name);
		
		JButton btnAddTrip = new JButton("Add trip");
		btnAddTrip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(TripControl.getInstance().addTrip(name.getText(), desc.getText(), start.getText(), end.getText(), Login.UNIQMEMBER ))
					JOptionPane.showMessageDialog(null, "trip added", "plain msg", JOptionPane.PLAIN_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
				
			}
		});
		btnAddTrip.setBounds(56, 190, 116, 23);
		contentPane.add(btnAddTrip);
		
		JLabel lblEnddate = new JLabel("EndDate:");
		lblEnddate.setBounds(10, 162, 133, 14);
		contentPane.add(lblEnddate);
		
		end = new JTextField();
		end.setColumns(10);
		end.setBounds(133, 159, 96, 20);
		contentPane.add(end);
		
		JLabel lblDdmmyyyy = new JLabel("yyyy-mm-dd");
		lblDdmmyyyy.setBounds(10, 108, 133, 14);
		contentPane.add(lblDdmmyyyy);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(310, 538, 170, 23);
		contentPane.add(btnToTheLogin);
		
		
		
		

	}
}

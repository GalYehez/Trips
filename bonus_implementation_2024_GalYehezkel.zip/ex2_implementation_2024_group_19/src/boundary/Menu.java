package boundary;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JMenuItem;

public class Menu extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    public static JDesktopPane desktopPane;

	/**
	 * Create the frame.
	 */
	public Menu() {
	
		setTitle("Menu admin");
		desktopPane = new JDesktopPane();
	    getContentPane().add(desktopPane);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 200, 600, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//label - hello
		JLabel lblNewLabel_1 = new JLabel("Hi member, please choose your actions");
		lblNewLabel_1.setForeground(new Color(30, 144, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_1.setBounds(109, 11, 416, 41);
		contentPane.add(lblNewLabel_1);
		
		//create menu bar
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 500, 22);
		//contentPane.add(menuBar);
		setJMenuBar(menuBar);
		
		JMenu AddTitle = new JMenu("Places");
		menuBar.add(AddTitle);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Manage Places");
		mntmNewMenuItem.addActionListener(e->openTripScreen());
		AddTitle.add(mntmNewMenuItem);
		
		JMenu mnMembers = new JMenu("Members");
		menuBar.add(mnMembers);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Manage Mambers");
		mntmNewMenuItem_1.addActionListener(e->openTripMemberScreen());
		mnMembers.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu = new JMenu("Reviews");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Add/Update review");
		mntmNewMenuItem_2.addActionListener(e->openReviewScreen());
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenu mnNewMenu_1 = new JMenu("Trips");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Create Trip");
		mntmNewMenuItem_3.addActionListener(e->openNewTripScreen());
		mnNewMenu_1.add(mntmNewMenuItem_3);
	}
	
	private void openReviewScreen() {
		Reviews revscreen = new Reviews();
		contentPane.add(revscreen);
		setContentPane(desktopPane);
		Menu.desktopPane.removeAll();
		desktopPane.add(revscreen);
		revscreen.setVisible(true);
		revscreen.moveToFront();
	}
	
	private void openTripScreen() {
		TripScreen tripscreen = new TripScreen();
		contentPane.add(tripscreen);
		setContentPane(desktopPane);
		Menu.desktopPane.removeAll();
		desktopPane.add(tripscreen);
		tripscreen.setVisible(true);
		tripscreen.moveToFront();
	}
	
	private void openTripMemberScreen() {
		TripMemberscreen tripsmembercreen = new TripMemberscreen();
		contentPane.add(tripsmembercreen);
		setContentPane(desktopPane);
		Menu.desktopPane.removeAll();
		desktopPane.add(tripsmembercreen);
		tripsmembercreen.setVisible(true);
		tripsmembercreen.moveToFront();
	}
	
	
	private void openNewTripScreen() {
		NewTrip newtrip = new NewTrip();
		contentPane.add(newtrip);
		setContentPane(desktopPane);
		Menu.desktopPane.removeAll();
		desktopPane.add(newtrip);
		newtrip.setVisible(true);
		newtrip.moveToFront();
	}
	
}

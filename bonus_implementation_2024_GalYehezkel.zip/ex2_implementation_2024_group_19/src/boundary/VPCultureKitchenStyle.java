package boundary;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.PlacesControl;
import entity.Restaurant;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class VPCultureKitchenStyle extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel tableModel;
	private JTextField num;

	public VPCultureKitchenStyle() {
		setBounds(100, 100, 450, 300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setToolTipText("");
		table.setForeground(Color.BLACK);
		table.setEnabled(false);
		table.setCellSelectionEnabled(true);
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(10, 45, 434, 152);
		contentPane.add(table);
		
		String[] columnNames = {"uniqueSerielNumber", "kitchenStyle"};
	     tableModel = new DefaultTableModel(columnNames,0);
	     
		table.setModel(tableModel);
		
		
		JButton btnSeeAllRestaurant = new JButton("See All Restaurant");
		btnSeeAllRestaurant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 	tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "kitchenStyle"};
		   	     	tableModel.addRow(rowData1);

					ArrayList<Restaurant> al =PlacesControl.getInstance().getRestaurant();

					 for (Restaurant element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getKitchenS()};
				            tableModel.addRow(rowData);
				        }
			}
		});
		btnSeeAllRestaurant.setBounds(10, 11, 139, 23);
		contentPane.add(btnSeeAllRestaurant);
		
		JLabel lblUpdateKitchenstyle = new JLabel("Update KitchenStyle:");
		lblUpdateKitchenstyle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUpdateKitchenstyle.setBounds(10, 380, 158, 23);
		contentPane.add(lblUpdateKitchenstyle);
		
		JLabel lblRestaurantNumber = new JLabel("Restaurant number:");
		lblRestaurantNumber.setBounds(10, 414, 139, 14);
		contentPane.add(lblRestaurantNumber);
		
		num = new JTextField();
		num.setColumns(10);
		num.setBounds(172, 411, 96, 20);
		contentPane.add(num);
		
		JLabel lblScore_1 = new JLabel("KitchenStyle:");
		lblScore_1.setBounds(10, 445, 121, 14);
		contentPane.add(lblScore_1);
		
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Indian", "Israeli", "Milky", "Fleshy", "Italian"}));
		comboBox.setBounds(172, 442, 96, 22);
		contentPane.add(comboBox);
		
		JButton btnGetAllReviews_1_1 = new JButton("Update restaurent");
		btnGetAllReviews_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String kitchenStyle = "";
				int a = comboBox.getSelectedIndex();

				if (a==0)
					kitchenStyle = "Indian";
				if (a==1)
					kitchenStyle = "Israeli";
				if (a==2)
					kitchenStyle = "Milky";
				if (a==3)
					kitchenStyle = "Fleshy";
				if (a==4)
					kitchenStyle = "Italian";

				if(PlacesControl.getInstance().updateKitchenStyle(kitchenStyle, Integer.valueOf(num.getText()) ))
					JOptionPane.showMessageDialog(null, "review updated", "plain msg", JOptionPane.PLAIN_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
				
			}
		});
		btnGetAllReviews_1_1.setBounds(50, 478, 170, 23);
		contentPane.add(btnGetAllReviews_1_1);
		
		JLabel lblNewLabel = new JLabel("Hello, VP of Culture!");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(220, 11, 224, 23);
		contentPane.add(lblNewLabel);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(318, 515, 158, 23);
		contentPane.add(btnToTheLogin);
		

		
	}
}

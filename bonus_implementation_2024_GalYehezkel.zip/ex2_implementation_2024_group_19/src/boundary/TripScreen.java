package boundary;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.MemberControl;
import control.PlacesControl;
import control.TripControl;
import entity.Place;
import entity.Trip;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class TripScreen extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableplaces;
	private DefaultTableModel tableModel;
	private DefaultTableModel tableModel1;
	private DefaultTableModel tableModel2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable tabletrips;
	private JTextField textField_5;
	private JTable tableplacetrip;
	private JTextField oktrips;


	/**
	 * Create the frame.
	 */
	public TripScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		tabletrips = new JTable();
		tabletrips.setCellSelectionEnabled(true);
		tabletrips.setEnabled(false);
		tabletrips.setToolTipText("");
		tabletrips.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"uniqueTripNumber", "start", "end", "createorNum", "description", "name"
			}
		));
		
		
		String[] columnNamesTrip = {"uniqueTripNumber", "start", "end", "createorNum", "description", "name"};
	    tableModel1 = new DefaultTableModel(columnNamesTrip,0);
		
		tabletrips.setBounds(20, 56, 431, 70);
		contentPane.add(tabletrips);
		
        Object[] rowData = {"uniqueNum", "start", "end", "createor", "description", "name"};
        tableModel1.addRow(rowData);


		
		tabletrips.setModel(tableModel1);
		
		JButton getTrips = new JButton("Get All Trips");
		getTrips.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<Trip> arrayList =TripControl.getInstance().getTrips();

				 for (Trip element : arrayList) {
			            Object[] rowData = {element.getUniqueTripNumber(), element.getStart(), element.getEnd(), element.getCreateorNum(), element.getDescription(), element.getName()};
			            tableModel1.addRow(rowData);
			        }
				
				
			}
		});
		getTrips.setBounds(10, 22, 116, 23);
		contentPane.add(getTrips);
		
		
		
		tableplaces = new JTable();
		tableplaces.setToolTipText("");
		tableplaces.setForeground(Color.BLACK);
		tableplaces.setEnabled(false);
		tableplaces.setCellSelectionEnabled(true);
		tableplaces.setBackground(Color.LIGHT_GRAY);
		tableplaces.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null},
				},
				new String[] {
					"uniqueSerielNumber", "name", "p.level", "cityCode","Country"
				}
			));
		tableplaces.setBounds(33, 249, 434, 100);
		
		String[] columnNames = {"uniqueSerielNumber", "name", "p.level", "cityCode","Country"};
	     tableModel = new DefaultTableModel(columnNames,0);

	     Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
	     tableModel.addRow(rowData1);
	     
		 tableplaces.setModel(tableModel);
		
		getContentPane().add(tableplaces);
		
		JButton gatplaces = new JButton("All Places - Manually State");
		gatplaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            tableModel.setRowCount(0);
	            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
	   	     	tableModel.addRow(rowData1);

				ArrayList<Place> al = TripControl.getInstance().getPlaces();

				 for (Place element : al) {
			            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
			            tableModel.addRow(rowData);
			        }
				
				
			}
		});
		gatplaces.setBounds(10, 137, 195, 23);
		contentPane.add(gatplaces);
		
		JLabel lblNewLabel = new JLabel("Add place to trip:");
		lblNewLabel.setBounds(45, 465, 95, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(131, 490, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(131, 521, 86, 20);
		contentPane.add(textField_1);
		
		JLabel lblNumberPlace = new JLabel("Number place:");
		lblNumberPlace.setBounds(45, 493, 95, 14);
		contentPane.add(lblNumberPlace);
		
		JLabel lblNumberTrip = new JLabel("Number Trip:");
		lblNumberTrip.setBounds(45, 524, 95, 14);
		contentPane.add(lblNumberTrip);
		
		JLabel lblFilterPlacesOr = new JLabel("Filter Places OR by recommandetions:");
		lblFilterPlacesOr.setBounds(225, 137, 223, 14);
		contentPane.add(lblFilterPlacesOr);
		
		JLabel lblAutomaticState = new JLabel("Automatic State - Choose trip:");
		lblAutomaticState.setBounds(225, 162, 188, 14);
		contentPane.add(lblAutomaticState);
		
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Places are available", "By recommondations", "By level price=low", "By level price=medium", "By level price=high", "By kitchen style=Indian", "By kitchen style=Israeli", "By kitchen style=Milky", "By kitchen style=Fleshy", "By kitchen style=Italian", "By Accommand.Stl=AA", "By Accommand.Stl=BB", "By Accommand.Stl=HB", "By Accommand.Stl=RO", "By Accommand.Stl=FB", "By Reviews: desc avgScore", "By city = Haifa", "By city = Tel Aviv", "By city = New York", "By country = Israel", "By country = USA"}));
		comboBox.setBounds(179, 187, 177, 23);
		contentPane.add(comboBox);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(398, 162, 69, 20);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("Add place");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
			if(TripControl.getInstance().addPlace( Integer.valueOf(textField.getText()),  Integer.valueOf(textField_1.getText()) ))
				JOptionPane.showMessageDialog(null, "place added", "plain msg", JOptionPane.PLAIN_MESSAGE);
			else
				JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnNewButton.setBounds(83, 549, 95, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblRemovePlaceFrom = new JLabel("Remove place from trip:");
		lblRemovePlaceFrom.setBounds(271, 468, 177, 14);
		contentPane.add(lblRemovePlaceFrom);
		
		JLabel lblNumberPlace_1 = new JLabel("Number place:");
		lblNumberPlace_1.setBounds(271, 493, 95, 14);
		contentPane.add(lblNumberPlace_1);
		
		JLabel lblNumberTrip_1 = new JLabel("Number Trip:");
		lblNumberTrip_1.setBounds(271, 524, 95, 14);
		contentPane.add(lblNumberTrip_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(357, 521, 86, 20);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(357, 490, 86, 20);
		contentPane.add(textField_4);
		
		JButton btnRemovePlace = new JButton("Remove place");
		btnRemovePlace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(TripControl.getInstance().removePlace( Integer.valueOf(textField_4.getText())  ,  Integer.valueOf(textField_3.getText())))
				JOptionPane.showMessageDialog(null, "place removed", "plain msg", JOptionPane.PLAIN_MESSAGE);
			else
				JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnRemovePlace.setBounds(294, 549, 130, 23);
		contentPane.add(btnRemovePlace);
		
		tableplacetrip = new JTable();
		tableplacetrip.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		tableplacetrip.setToolTipText("");
		tableplacetrip.setForeground(Color.BLACK);
		tableplacetrip.setEnabled(false);
		tableplacetrip.setCellSelectionEnabled(true);
		tableplacetrip.setBackground(Color.LIGHT_GRAY);
		tableplacetrip.setBounds(43, 385, 431, 61);
		contentPane.add(tableplacetrip);
		
		String[] columnPlaceInTrip = {"uniqueNum", "name", "p.level", "cityCode","Country"};
	    tableModel2 = new DefaultTableModel(columnPlaceInTrip,0);
		
		tableplacetrip.setModel(tableModel2);
		 Object[] rowDataa = {"uniqueNum", "name", "p.level", "cityCode","Country"};
	     tableModel2.addRow(rowDataa);
	     	
		JLabel lblNewLabel_3 = new JLabel("Places in the trip you chose:");
		lblNewLabel_3.setBounds(50, 360, 228, 14);
		contentPane.add(lblNewLabel_3);
		
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<Place> al5 = TripControl.getInstance().getPlaceintrip(Integer.valueOf(textField_2.getText()));
	            tableModel2.setRowCount(0);
	   	     tableModel2.addRow(rowDataa);

				 for (Place element : al5) {
			            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
			            tableModel2.addRow(rowData);
			        }
				
				
				
				int a = comboBox.getSelectedIndex();
				if(a == 0)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlace(Integer.valueOf(textField_2.getText()));
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
					
				if (a==1)
				{
					ArrayList<Place> al4 = TripControl.getInstance().getOKPlaceByReccommandation(Integer.valueOf(textField_2.getText()),Integer.valueOf(textField_2.getText()),Integer.valueOf(textField_5.getText()));
					tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al4) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }

				}
				if (a==2)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByPrice(Integer.valueOf(textField_2.getText()),"low");
		            tableModel.setRowCount(0);
		            
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
		   	     	
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==3)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByPrice(Integer.valueOf(textField_2.getText()),"medium");
		            tableModel.setRowCount(0);
		            
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
		   	     	
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==4)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByPrice(Integer.valueOf(textField_2.getText()),"high");
		            tableModel.setRowCount(0);
		            
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
		   	     	
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==5)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByKitchen(Integer.valueOf(textField_2.getText()),"Indian");

		            tableModel.setRowCount(0);
		         
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
		   	     	
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}

				if (a==6)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByKitchen(Integer.valueOf(textField_2.getText()),"Israeli");

		            tableModel.setRowCount(0);
		            
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
		   	     	
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}

				if (a==7)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByKitchen(Integer.valueOf(textField_2.getText()),"Milky");
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}

				if (a==8)
				{
					
						ArrayList<Place> al = TripControl.getInstance().getOKPlaceByKitchen(Integer.valueOf(textField_2.getText()),"Fleshy");
			            tableModel.setRowCount(0);
			            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
			   	     	tableModel.addRow(rowData1);
						 for (Place element : al) {
					            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
					            tableModel.addRow(rowData);
					        }
					
				}

				if (a==9)
				{
					
						ArrayList<Place> al = TripControl.getInstance().getOKPlaceByKitchen(Integer.valueOf(textField_2.getText()),"Italian");
			            tableModel.setRowCount(0);
			            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
			   	     	tableModel.addRow(rowData1);
						 for (Place element : al) {
					            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
					            tableModel.addRow(rowData);
					        }
					
				}
				if (a==10)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByAccommandationStyle(Integer.valueOf(textField_2.getText()),1);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==11)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByAccommandationStyle(Integer.valueOf(textField_2.getText()),2);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==12)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByAccommandationStyle(Integer.valueOf(textField_2.getText()),3);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==13)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByAccommandationStyle(Integer.valueOf(textField_2.getText()),4);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				if (a==14)
				{
					ArrayList<Place> al = TripControl.getInstance().getOKPlaceByAccommandationStyle(Integer.valueOf(textField_2.getText()),5);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if (a==15)
				{
					ArrayList<Place> al3 = TripControl.getInstance().getOKPlaceByAVGReviews(Integer.valueOf(textField_2.getText()));				
					 tableModel.setRowCount(0);
			            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
			   	     	tableModel.addRow(rowData1);
						 for (Place element : al3) {
					            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
					            tableModel.addRow(rowData);
					        }

				}
				
				if(a == 16)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(1);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 17)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(2);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 18)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(3);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 19)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCountry("israel");
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 20)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCountry("usa");
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}

				
			}
		});
		btnSearch.setBounds(381, 187, 86, 23);
		contentPane.add(btnSearch);
		
		JLabel lblNewLabel_1 = new JLabel("PERFECT TRIP - Manage trip's places");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(135, 0, 332, 29);
		contentPane.add(lblNewLabel_1);
		
		textField_5 = new JTextField();
		textField_5.setBounds(381, 218, 86, 20);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("If you choose recommandation, disatance:");
		lblNewLabel_2.setBounds(135, 221, 268, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblYouCanEdit = new JLabel("You can edit these trips:");
		lblYouCanEdit.setBounds(10, 451, 217, 14);
		contentPane.add(lblYouCanEdit);
		
		oktrips = new JTextField();
		oktrips.setColumns(10);
		oktrips.setBounds(162, 448, 149, 20);
		contentPane.add(oktrips);
		
		ArrayList<String> stringList = new ArrayList<>();
        MemberControl.getInstance();
		for (Integer intValue : MemberControl.getTripsOfMember(Login.UNIQMEMBER) ) {
            String strValue = Integer.toString(intValue);
            stringList.add(strValue);
        }
        
        StringBuilder stringBuilder = new StringBuilder();
        for (String str : stringList) {
            stringBuilder.append(str).append("\n"); // Add each string followed by a newline character
        }
        String concatenatedText = stringBuilder.toString();
		
		oktrips.setText(concatenatedText);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(10, 187, 95, 23);
		contentPane.add(btnToTheLogin);
		
		
		
		
	
	}
}

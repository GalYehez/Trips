package boundary;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.ReviewControl;
import entity.Review;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Reviews extends JInternalFrame {
	
	private static final long serialVersionUID = 1L;
	private JTable table;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField newtxt;
	private JTextField numrev;
	private DefaultTableModel tableModel1;
	private JTextField newscore;

	public Reviews() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JButton btnGetAllReviews = new JButton("Get All Reviews");
		btnGetAllReviews.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<Review> arrayList =ReviewControl.getInstance().getReviews();
	            tableModel1.setRowCount(0);
	            Object[] rowData1 = {"uniqueNumber", "score", "time", "member number", "place number", "text"};
	            tableModel1.addRow(rowData1);
				 for (Review element : arrayList) {
			            Object[] rowData = {element.getUniqueNumber(), element.getScore(), element.getTime(), element.getMembernum(), element.getPlacenum(), element.getText()};

			            tableModel1.addRow(rowData);
			        }
			}
		});
		btnGetAllReviews.setBounds(22, 29, 116, 23);
		getContentPane().add(btnGetAllReviews);
		
		table = new JTable();
		table.setCellSelectionEnabled(true);
		table.setEnabled(false);
		table.setToolTipText("");
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"uniqueNumber", "score", "time", "member number", "place number", "text"
			}
		));
		
		
		String[] columnNamesTrip = {"uniqueNumber", "score", "time", "member number", "place number", "text"};
	    tableModel1 = new DefaultTableModel(columnNamesTrip,0);
		
	    table.setBounds(22, 63, 431, 205);
		contentPane.add(table);
		
        Object[] rowData = {"uniqueNumber", "score", "time", "member number", "place number", "text"};
        tableModel1.addRow(rowData);
		
        table.setModel(tableModel1);
		
		JLabel lblNewLabel_1 = new JLabel("PERFECT TRIP - Manage place's reviews");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(22, 0, 445, 29);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnAddReview = new JButton("Add review");
		btnAddReview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ReviewControl.getInstance().addReview(Integer.valueOf(textField_1.getText()),  Integer.valueOf(textField_2.getText()),Integer.valueOf(textField.getText()),textField_4.getText() ))
					JOptionPane.showMessageDialog(null, "review added", "plain msg", JOptionPane.PLAIN_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
				
			}
		});
		btnAddReview.setBounds(178, 397, 116, 23);
		getContentPane().add(btnAddReview);
		
		JButton btnGetAllReviews_1_1 = new JButton("Update review");
		btnGetAllReviews_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ReviewControl.getInstance().updateReview(Integer.valueOf(newscore.getText()), Integer.valueOf(numrev.getText()), newtxt.getText() ))
					JOptionPane.showMessageDialog(null, "review updated", "plain msg", JOptionPane.PLAIN_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnGetAllReviews_1_1.setBounds(178, 550, 116, 23);
		getContentPane().add(btnGetAllReviews_1_1);
		
		textField = new JTextField();
		textField.setBounds(147, 304, 96, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(147, 335, 96, 20);
		getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(147, 366, 96, 20);
		getContentPane().add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(295, 332, 158, 51);
		getContentPane().add(textField_4);
		
		JLabel lblNewLabel = new JLabel("Place number:");
		lblNewLabel.setBounds(24, 304, 102, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblScore = new JLabel("Score:");
		lblScore.setBounds(24, 335, 102, 14);
		getContentPane().add(lblScore);
		
		JLabel lblWriterId = new JLabel("Writer Unique number:");
		lblWriterId.setBounds(24, 369, 133, 14);
		getContentPane().add(lblWriterId);
		
		JLabel lblNewLabel_2 = new JLabel("Text review:");
		lblNewLabel_2.setBounds(295, 307, 89, 14);
		getContentPane().add(lblNewLabel_2);
		
		newtxt = new JTextField();
		newtxt.setColumns(10);
		newtxt.setBounds(295, 488, 158, 51);
		getContentPane().add(newtxt);
		
		JLabel lblNewLabel_2_1 = new JLabel("New text review:");
		lblNewLabel_2_1.setBounds(295, 463, 89, 14);
		getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblReviewNumber = new JLabel("Review number:");
		lblReviewNumber.setBounds(24, 463, 102, 14);
		getContentPane().add(lblReviewNumber);
		
		numrev = new JTextField();
		numrev.setColumns(10);
		numrev.setBounds(147, 463, 96, 20);
		getContentPane().add(numrev);
		
		JLabel lblUpdateReview = new JLabel("Update review:");
		lblUpdateReview.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUpdateReview.setBounds(24, 438, 158, 14);
		getContentPane().add(lblUpdateReview);
		
		JLabel lblAddReview = new JLabel("Add review:");
		lblAddReview.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAddReview.setBounds(24, 279, 133, 14);
		getContentPane().add(lblAddReview);
		contentPane.setLayout(null);
		
		JLabel lblScore_1 = new JLabel("Score:");
		lblScore_1.setBounds(24, 494, 102, 14);
		contentPane.add(lblScore_1);
		
		newscore = new JTextField();
		newscore.setColumns(10);
		newscore.setBounds(147, 494, 96, 20);
		contentPane.add(newscore);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(310, 550, 170, 23);
		contentPane.add(btnToTheLogin);
	}
}

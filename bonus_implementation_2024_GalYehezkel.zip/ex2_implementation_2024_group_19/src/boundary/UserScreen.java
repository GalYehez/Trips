package boundary;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.MemberControl;
import control.PlacesControl;
import control.TripControl;
import entity.Place;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;

public class UserScreen extends JFrame {

	private JPanel contentPane;
	private static final long serialVersionUID = 1L;
	private JTextField id;
	private JTextField fname;
	private JTextField lname;
	private JTextField mail;
	private JTable table;
	private DefaultTableModel tableModel;
	private JTextField newpass;
	
	public UserScreen() {
		setBounds(100, 100, 450, 300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(40, 0, 500, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setToolTipText("");
		table.setForeground(Color.BLACK);
		table.setEnabled(false);
		table.setCellSelectionEnabled(true);
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(33, 321, 434, 244);
		contentPane.add(table);
		
		String[] columnNames = {"uniqueSerielNumber", "name", "p.level", "cityCode","Country"};
	     tableModel = new DefaultTableModel(columnNames,0);
	     
		table.setModel(tableModel);
		
		
		JLabel lblNewLabel = new JLabel("I am new member - Registration:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(10, 11, 312, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblSearchPlaces = new JLabel("Search Places:");
		lblSearchPlaces.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblSearchPlaces.setBounds(10, 184, 312, 14);
		contentPane.add(lblSearchPlaces);
		
		JLabel lblNewLabel_1 = new JLabel("ID:");
		lblNewLabel_1.setBounds(10, 50, 49, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("First name:");
		lblNewLabel_1_1.setBounds(10, 86, 94, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Last name:");
		lblNewLabel_1_1_1.setBounds(10, 122, 94, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Email:");
		lblNewLabel_1_1_1_1.setBounds(261, 50, 49, 14);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		id = new JTextField();
		id.setBounds(91, 47, 77, 20);
		contentPane.add(id);
		id.setColumns(10);
		
		fname = new JTextField();
		fname.setColumns(10);
		fname.setBounds(91, 83, 77, 20);
		contentPane.add(fname);
		
		lname = new JTextField();
		lname.setColumns(10);
		lname.setBounds(91, 119, 77, 20);
		contentPane.add(lname);
		
		mail = new JTextField();
		mail.setColumns(10);
		mail.setBounds(329, 47, 77, 20);
		contentPane.add(mail);
		
		JButton btnSeeAllPlaces = new JButton("See All Places");
		btnSeeAllPlaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableModel.setRowCount(0);
	            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
	   	     	tableModel.addRow(rowData1);

				ArrayList<Place> al = TripControl.getInstance().getPlaces();

				 for (Place element : al) {
			            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
			            tableModel.addRow(rowData);
			        }
				
			}
		});
		btnSeeAllPlaces.setBounds(10, 209, 139, 23);
		contentPane.add(btnSeeAllPlaces);
	
		
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"By city = Haifa", "By city = Tel Aviv", "By city = New York", "By country = Israel", "By country = USA", "", ""}));
		comboBox.setBounds(179, 259, 177, 23);
		contentPane.add(comboBox);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int a = comboBox.getSelectedIndex();
				if(a == 0)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(1);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 1)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(2);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 2)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCity(3);
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 3)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCountry("israel");
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
				if(a == 4)
				{
					ArrayList<Place> al = PlacesControl.getInstance().getOKPlaceByCountry("usa");
		            tableModel.setRowCount(0);
		            Object[] rowData1 = {"uniqueNum", "name", "p.level", "cityCode","Country"};
		   	     	tableModel.addRow(rowData1);
					 for (Place element : al) {
				            Object[] rowData = {element.getUniqueSerielNumber(), element.getName(), element.getP(), element.getCity(), element.getCountry()};
				            tableModel.addRow(rowData);
				        }
				}
				
			}
		});
		btnSearch.setBounds(381, 259, 86, 23);
		contentPane.add(btnSearch);
		
		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("Filter by city / country:");
		lblNewLabel_1_1_1_1_2.setBounds(179, 233, 159, 14);
		contentPane.add(lblNewLabel_1_1_1_1_2);
		
		
		newpass = new JTextField();
		newpass.setColumns(10);
		newpass.setBounds(377, 151, 99, 20);
		contentPane.add(newpass);
		
		JButton btnRegistrationMeAs = new JButton("Registration me as a member");
		btnRegistrationMeAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(MemberControl.addNewMember(Integer.valueOf(id.getText()), fname.getText(), lname.getText(), mail.getText()))
					JOptionPane.showMessageDialog(null, "member added", "plain msg", JOptionPane.PLAIN_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"error", "alert msg", JOptionPane.ERROR_MESSAGE);

				newpass.setText(MemberControl.getPassmember(Integer.valueOf(id.getText())));
				
				
			}
		});
		btnRegistrationMeAs.setBounds(124, 150, 243, 23);
		contentPane.add(btnRegistrationMeAs);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Your passward:");
		lblNewLabel_1_1_1_1_1.setBounds(381, 133, 139, 14);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		JButton btnToTheLogin = new JButton("Exit to the Login");
		btnToTheLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login p = new Login();
				p.setVisible(true);
				dispose();
			}
		});
		btnToTheLogin.setBounds(10, 259, 95, 23);
		contentPane.add(btnToTheLogin);
	
	}
}

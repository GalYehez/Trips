package entity;

import java.util.Objects;

public class Hotel extends Place {
	

	private AccommodationStyle a;
	private Stars s;
	
	public Hotel(int uniqueSerielNumber, String name, String description, int coordinates, String p, int cityCode,
			String country, AccommodationStyle a, Stars s) {
		super(uniqueSerielNumber, name, description, coordinates, p, cityCode, country);
		this.a = a;
		this.s = s;
	}

	
	

	
	public AccommodationStyle getA() {
		return a;
	}
	public void setA(AccommodationStyle a) {
		this.a = a;
	}
	public Stars getS() {
		return s;
	}
	public void setS(Stars s) {
		this.s = s;
	}


	@Override
	public String toString() {
		return "Hotel [a=" + a + ", s=" + s + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(a, s);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotel other = (Hotel) obj;
		return a == other.a && s == other.s;
	}


}

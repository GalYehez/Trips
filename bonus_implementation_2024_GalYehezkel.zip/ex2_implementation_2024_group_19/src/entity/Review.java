package entity;

import java.time.LocalDateTime;
import java.util.Objects;

public class Review {

	public Review(int uniqueNumber, int score, LocalDateTime time, int membernum, int placenum, String text) {
		super();
		UniqueNumber = uniqueNumber;
		Score = score;
		this.time = time;
		this.membernum = membernum;
		this.placenum = placenum;
		this.text = text;
	}
	public Review(int score, int membernum, int placenum, String text) {
        this.Score = score;
        this.time = LocalDateTime.now();
        this.membernum = membernum;
        this.placenum = placenum;
        this.text = text;
    }
	
	private int UniqueNumber;
	private int Score;
	private LocalDateTime time;
	private int membernum;
	private int placenum;
	private String text;
	
	public int getUniqueNumber() {
		return UniqueNumber;
	}
	public void setUniqueNumber(int uniqueNumber) {
		UniqueNumber = uniqueNumber;
	}
	public int getScore() {
		return Score;
	}
	public void setScore(int score) {
		Score = score;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public int getMembernum() {
		return membernum;
	}
	public void setMembernum(int membernum) {
		this.membernum = membernum;
	}
	public int getPlacenum() {
		return placenum;
	}
	public void setPlacenum(int placenum) {
		this.placenum = placenum;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	@Override
	public int hashCode() {
		return Objects.hash(Score, UniqueNumber, membernum, placenum, text, time);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		return Score == other.Score && UniqueNumber == other.UniqueNumber && membernum == other.membernum
				&& placenum == other.placenum && Objects.equals(text, other.text) && Objects.equals(time, other.time);
	}
	@Override
	public String toString() {
		return "Review [UniqueNumber=" + UniqueNumber + ", Score=" + Score + ", time=" + time + ", membernum="
				+ membernum + ", placenum=" + placenum + ", text=" + text + "]";
	}


	
}

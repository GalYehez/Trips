package entity;

public enum AccommodationStyle {
	
	AI, BB, HB, FB, RO

}

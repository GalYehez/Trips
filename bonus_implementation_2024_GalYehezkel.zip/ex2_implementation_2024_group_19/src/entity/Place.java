package entity;

import java.util.Objects;

public class Place {
	
	protected int uniqueSerielNumber;
	private String name;
	private String pricelevel;
	private int cityCode;
	private String Country;
	private String description;
	private int coordinates;
	
	public Place(int uniqueSerielNumber, String name, String description, int coordinates, 
			String p, int cityCode, String country) {
		super();
		this.uniqueSerielNumber = uniqueSerielNumber;
		this.name = name;
		this.pricelevel = p;
		this.cityCode = cityCode;
		Country = country;
		this.description = description;
		this.coordinates = coordinates;
	}
	
	public Place(String name, String description, int coordinates, String p, int cityCode, String country) {
		super();
		this.name = name;
		this.pricelevel = p;
		this.cityCode = cityCode;
		Country = country;
		this.description = description;
		this.coordinates = coordinates;
	}

	public Place() {
		// TODO Auto-generated constructor stub
	}

	public int getUniqueSerielNumber() {
		return uniqueSerielNumber;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return Country;
	}
	
	public int getCity() {
		return cityCode;
	}
	
	public String getP() {
		return pricelevel;
	}
	
	public void setCountry(String country) {
		Country = country;
	}
	@Override
	public int hashCode() {
		return Objects.hash(Country, cityCode, name, pricelevel, uniqueSerielNumber);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Place other = (Place) obj;
		return Objects.equals(Country, other.Country) && Objects.equals(cityCode, other.cityCode)
				&& Objects.equals(name, other.name) && pricelevel == other.pricelevel && uniqueSerielNumber == other.uniqueSerielNumber;
	}
	@Override
	public String toString() {
		return "Place [uniqueSerielNumber=" + uniqueSerielNumber + ", name=" + name + ", p=" + pricelevel + ", cityCode="
				+ cityCode + ", Country=" + Country + "]";
	}


	public String getPricelevel() {
		return pricelevel;
	}


	public void setPricelevel(String pricelevel) {
		this.pricelevel = pricelevel;
	}


	public int getCityCode() {
		return cityCode;
	}


	public void setCityCode(int cityCode) {
		this.cityCode = cityCode;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getCoordinates() {
		return coordinates;
	}


	public void setCoordinates(int coordinates) {
		this.coordinates = coordinates;
	}


	public void setUniqueSerielNumber(int uniqueSerielNumber) {
		this.uniqueSerielNumber = uniqueSerielNumber;
	}

}

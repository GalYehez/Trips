package entity;

import java.util.Objects;

public class Restaurant extends Place {
	
		private String kitchenS;

	public Restaurant(int uniqueSerielNumber, String name, String description, int coordinates, String p,
			int cityCode, String country, String kitchenS) {
		super(uniqueSerielNumber, name, description, coordinates, p, cityCode, country);
		this.kitchenS = kitchenS;
	}
	




	public Restaurant(int UniquePlaceNumber, String kitchenS) {
		// TODO Auto-generated constructor stub
		super();
		this.uniqueSerielNumber = UniquePlaceNumber;

		this.kitchenS = kitchenS;

	}





	public String getKitchenS() {
		return kitchenS;
	}

	public void setKitchenS(String kitchenS) {
		this.kitchenS = kitchenS;
	}

	@Override
	public String toString() {
		return "Restaurant [kitchenS=" + kitchenS + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(kitchenS);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Restaurant other = (Restaurant) obj;
		return Objects.equals(kitchenS, other.kitchenS);
	}

}

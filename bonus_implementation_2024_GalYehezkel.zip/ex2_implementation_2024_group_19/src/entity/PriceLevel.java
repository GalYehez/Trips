package entity;

public enum PriceLevel {
	
	Low, Medium, High

}

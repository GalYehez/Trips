package entity;

import java.sql.Date;
import java.util.Objects;

public class Trip {
	
	private int uniqueTripNumber;
	private Date start;
	private Date end;
	private int createorNum;
	private String description;
	private String name;
	
	public Trip(int uniqueTripNumber, String name, String description, Date start, Date end, int createorNum) {
		super();
		this.uniqueTripNumber = uniqueTripNumber;
		this.start = start;
		this.end = end;
		this.description=description;
		this.createorNum=createorNum;
		this.name = name;
	}
	
	
	public int getUniqueTripNumber() {
		return uniqueTripNumber;
	}
	public void setUniqueTripNumber(int uniqueTripNumber) {
		this.uniqueTripNumber = uniqueTripNumber;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}


	@Override
	public String toString() {
		return "Trip [uniqueTripNumber=" + uniqueTripNumber + ", start=" + start + ", end=" + end + ", createorNum="
				+ createorNum + ", description=" + description + ", name=" + name + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(createorNum, description, end, name, start, uniqueTripNumber);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trip other = (Trip) obj;
		return createorNum == other.createorNum && Objects.equals(description, other.description)
				&& Objects.equals(end, other.end) && Objects.equals(name, other.name)
				&& Objects.equals(start, other.start) && uniqueTripNumber == other.uniqueTripNumber;
	}


	public int getCreateorNum() {
		return createorNum;
	}


	public void setCreateorNum(int createorNum) {
		this.createorNum = createorNum;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

}

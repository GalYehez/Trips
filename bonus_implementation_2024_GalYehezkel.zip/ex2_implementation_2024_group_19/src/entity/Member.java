package entity;

import java.util.Objects;

public class Member {
	
	public Member(int UniqueNumber, String iD, String fname, String lname, String email) {
		super();
		this.UniqueNumber = UniqueNumber;
		ID = iD;
		Fname = fname;
		Lname = lname;
		this.email = email;
	}
	private int UniqueNumber;
	private String ID;
	private String Fname;
	private String Lname;
	private String email;
	public int getUniqueNumber() {
		return UniqueNumber;
	}
	public void setUniqueNumber(int UniqueNumber) {
		this.UniqueNumber = UniqueNumber;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Member [UniqueNumber=" + UniqueNumber + ", ID=" + ID + ", Fname=" + Fname + ", Lname=" + Lname
				+ ", email=" + email + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(Fname, ID, Lname, email, UniqueNumber);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		return Objects.equals(Fname, other.Fname) && Objects.equals(ID, other.ID) && Objects.equals(Lname, other.Lname)
				&& Objects.equals(email, other.email) && UniqueNumber == other.UniqueNumber;
	}
	
	

}

package entity;

public enum Stars {
	
	Zero, One, Two, Three, Four, Five

}

package entity;

import java.net.URLDecoder;

/**
 * http://www.javapractices.com/topic/TopicAction.do?Id=2
 */
public final class Consts {
	private Consts() {
		throw new AssertionError();
	}

	protected static final String DB_FILEPATH = getDBPath();
	public static final String CONN_STR = "jdbc:ucanaccess://" + DB_FILEPATH + ";COLUMNORDER=DISPLAY";
	
	
	/*----------------------------------------- TRIP PLACE QUERIES -----------------------------------------*/
	public static final String SQL_SEL_TRIP = "SELECT * FROM tblTrip";   ///עשיתי
	public static final String SQL_DEL_PLACE = "{ call qryDelPlace(?,?) }"; ///עשיתי
	public static final String SQL_INS_PLACE = "{ call qryInsPlace(?,?) }"; ///עשיתי
	public static final String SQL_SEL_PLACE = "SELECT * FROM tblPlace"; ///עשיתי

	public static final String SQL_TRIP_OK_PLACE = "SELECT tblPlace.* FROM tblPlace WHERE (tblPlace.UniquePlaceNumber) Not In"
	+ " (SELECT tblPlaceTrip.UniquePlaceNumber FROM tblPlaceTrip WHERE (((tblPlaceTrip.UniqeTripNumber)=?)));"; ///עשיתי
	
	public static final String SQL_SEL_PLACES_NOT_IN_TRIP_BY_PRICE = "{ call qryByPrice(?,?) }"; ///עשיתי
	public static final String SQL_SEL_PLACES_NOT_IN_TRIP_BY_KITCHEN = "{ call qryByKitchenStyle(?,?) }"; ///עשיתי
	public static final String SQL_SEL_PLACES_NOT_IN_TRIP_BY_ACCOMMANDATIONSTYLE = "{ call qryByAccomondationStyle(?,?) }"; ///עשיתי
	
	public static final String SQL_SEL_PLACES_BY_RECCOMMANDATION = "{ call Query2(?,?,?) }";
	public static final String SQL_SEL_PLACES_BY_DISTANCE = "SELECT Query1.UniquePlaceNumber " +
            "FROM tblPlaceTrip " +
            "INNER JOIN (Query3 " +
            "INNER JOIN (tblPlacesDistance " +
            "INNER JOIN Query1 ON tblPlacesDistance.UniquePlaceNumber1 = Query1.UniquePlaceNumber) " +
            "ON Query3.UniquePlaceNumber = Query1.UniquePlaceNumber) " +
            "ON tblPlaceTrip.UniquePlaceNumber = tblPlacesDistance.UniquePlaceNumber2 " +
            "WHERE tblPlacesDistance.Distance < ? " +
            "AND UniqeTripNumber = ? " + 
            "AND UniqeTripNumber = ? " + 
            "ORDER BY Query3.AvgOfscore DESC;";
	
///מדפיסה מקומות זמינים ואת הממוצע ביקורות
	public static final String SQL_SEL_PLACES_BY_PLACE_OK_AND_REVIEWS1 = "SELECT tblPlace.UniquePlaceNumber, Avg(tblReview.score) AS AvgOfscore"
	+" FROM (tblPlace INNER JOIN Query1 ON tblPlace.UniquePlaceNumber = Query1.UniquePlaceNumber) INNER JOIN tblReview ON tblPlace.UniquePlaceNumber = tblReview.UniqePlaceNumber"
	+" GROUP BY tblPlace.UniquePlaceNumber, tblReview.UniqePlaceNumber, Query1.UniquePlaceNumber = ?;";///עשיתי
	
	public static final String SQL_SEL_PLACE_BY_PLACE_NUM = "SELECT tblPlace.* FROM tblPlace WHERE tblPlace.UniquePlaceNumber=(?)";///עשיתי
	
	public static final String SQL_SEL_PLACE_IN_TRIP= "{ call Query4(?) }";

	/*----------------------------------------- TRIP MEMBERS QUERIES -----------------------------------------*/
	public static final String SQL_SEL_MEMBER = "SELECT * FROM tblMember"; ///עשיתי
	public static final String SQL_DEL_MEMBER = "{ call qryDelMember(?,?) }"; ///עשיתי
	public static final String SQL_INS_MEMBER = "{ call qryInsMember(?,?) }"; ///עשיתי
	public static final String SQL_TRIP_OK_MEMBER = "SELECT tblMember.* FROM tblMember WHERE (tblMember.UniqueNumber) Not In"
	+ " (SELECT tblTripMember.UniqueNumberMember FROM tblTripMember WHERE (((tblTripMember.UniqueTripNumber)=?)));"; ///
	public static final String SQL_SEL_MEMBER_IN_TRIP= "{ call Query5(?) }";
	/*----------------------------------------- REVIEWS QUERIES -----------------------------------------*/
	public static final String SQL_SEL_REV = "SELECT * FROM tblReview"; ///עשיתי
	public static final String SQL_INS_REV = "{ call qryInsReview(?,?,?,?) }"; ///עשיתי
	public static final String SQL_UP_REV = "{ call qryUpdateReview(?,?,?) }"; ///עשיתי
	
	public static final String SQL_INS_NEWPLACE = "{ call qryInsNewPlace(?,?,?,?,?,?) }";
	
	public static final String SQL_SEL_PLACE_BY_CITY = "{ call qryPlaceByCity(?) }"; ///עשיתי
	public static final String SQL_SEL_PLACE_BY_COUNTRY = "{ call qryPlaceByCountry(?) }"; ///עשיתי
	public static final String SQL_INS_MEMBER_NEW = "{ call qryInsNewMember(?,?,?,?) }"; ///עשיתי
	
	public static final String SQL_SEL_MEMBER_PASS = "{ call qryGetPasswardMember(?) }"; ///עשיתי
	
	public static final String SQL_INS_TRIP = "{ call qryInsTrip(?,?,?,?,?) }";
	
	public static final String SQL_GET_UNIQUENUM = "{ call qryGetUniqueNumMember(?) }";
	
	public static final String SQL_GET_TRIPS_OF_MEMBER = "{ call qryGetTripsOfMember(?) }";
	
	public static final String SQL_UP_KITCHENSTYLE = "{ call qryUpdateKitchen(?,?) }";
	
	public static final String SQL_SEL_REST = "SELECT * FROM tblResturant";   ///עשיתי



	
	/*private static String getDBPath() {
		try {
			String path = Consts.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String decoded = URLDecoder.decode(path, "UTF-8");
			 //System.out.println(decoded);// - Can help to check the returned path
			if (decoded.contains(".jar")) {

				decoded = decoded.substring(0, decoded.lastIndexOf('/'));
				return decoded + "/libs/DataBaseHW1.accdb";
			} else {
				decoded = decoded.substring(0, decoded.lastIndexOf("bin/"));
				System.out.println(decoded);
				return decoded + "src/entity/DataBaseHW1.accdb";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}*/
	
	
	//////
	private static String getDBPath() {
		try {
			
			String path = Consts.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String decoded = URLDecoder.decode(path, "UTF-8");
			System.out.println(""+decoded);
			// System.out.println(decoded) - Can help to check the returned path
			if (decoded.contains("/bin")) {
				System.out.println("got into else");
				decoded = decoded.substring(0, decoded.lastIndexOf("bin/"));
				System.out.println(decoded);
				return decoded + "src/entity/DataBaseHW1.accdb";					
			} else {
				return "libs/database/DataBaseHW1.accdb";
			}
		} catch (Exception e) {
			System.out.println("got exception");
			e.printStackTrace();
			return null;
		}
	}
	//////
	
}

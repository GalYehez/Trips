package entity;

import java.sql.Date;
import java.util.Objects;

public class PlaceTrip {

	public PlaceTrip(int uniqueSerielNumber, int uniqueTripNumber, Date start) {
		super();
		this.uniqueSerielNumber = uniqueSerielNumber;
		this.uniqueTripNumber = uniqueTripNumber;
		this.start = start;
	}
	
	private int uniqueSerielNumber;
	private int uniqueTripNumber;
	private Date start;
	
	public int getUniqueSerielNumber() {
		return uniqueSerielNumber;
	}

	public int getUniqueTripNumber() {
		return uniqueTripNumber;
	}

	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	@Override
	public int hashCode() {
		return Objects.hash(start, uniqueSerielNumber, uniqueTripNumber);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlaceTrip other = (PlaceTrip) obj;
		return Objects.equals(start, other.start) && uniqueSerielNumber == other.uniqueSerielNumber
				&& uniqueTripNumber == other.uniqueTripNumber;
	}
	@Override
	public String toString() {
		return "PlaceTrip [uniqueSerielNumber=" + uniqueSerielNumber + ", uniqueTripNumber=" + uniqueTripNumber
				+ ", start=" + start + "]";
	}
	
}
